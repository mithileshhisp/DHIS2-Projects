/**
 * Created by hisp on 1/12/15.
 */

msfReportsApp
.controller('homeController', function( $rootScope,
                                         $scope){


    });
